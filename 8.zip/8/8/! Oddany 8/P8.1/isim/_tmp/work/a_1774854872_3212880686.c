/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                         */
/*  \   \        Copyright (c) 2003-2007 Xilinx, Inc.                 */
/*  /   /        All Right Reserved.                                  */
/* /---/   /\                                                         */
/* \   \  /  \                                                        */
/*  \___\/\___\                                                       */
/**********************************************************************/

/* This file is designed for use with ISim build 0x734844ce */

#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/studia/Sem4/IUP/8/! Oddany 8/P8.1/main.vhd";
extern char *IEEE_P_2592010699;

unsigned char p_2592010699_sub_1744673427_2592010699(char *, char *, unsigned int , unsigned int );


static void work_a_1774854872_3212880686_p_0(char *t0)
{
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    unsigned char t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    unsigned char t13;

LAB0:    xsi_set_current_line(61, ng0);
    t1 = (t0 + 1320U);
    t2 = p_2592010699_sub_1744673427_2592010699(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 2608);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(63, ng0);
    t3 = (t0 + 724U);
    t4 = *((char **)t3);
    t5 = *((unsigned char *)t4);
    t6 = (t5 == (unsigned char)3);
    if (t6 != 0)
        goto LAB5;

LAB7:
LAB6:    xsi_set_current_line(67, ng0);
    t1 = (t0 + 1076U);
    t3 = *((char **)t1);
    t5 = *((unsigned char *)t3);
    t6 = (t5 == (unsigned char)3);
    if (t6 == 1)
        goto LAB11;

LAB12:    t2 = (unsigned char)0;

LAB13:    if (t2 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(71, ng0);
    t1 = (t0 + 2696);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t7 = (t4 + 40U);
    t9 = *((char **)t7);
    *((unsigned char *)t9) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB9:    goto LAB3;

LAB5:    xsi_set_current_line(64, ng0);
    t3 = (t0 + 724U);
    t7 = *((char **)t3);
    t8 = *((unsigned char *)t7);
    t3 = (t0 + 2660);
    t9 = (t3 + 32U);
    t10 = *((char **)t9);
    t11 = (t10 + 40U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t8;
    xsi_driver_first_trans_fast(t3);
    goto LAB6;

LAB8:    xsi_set_current_line(68, ng0);
    t1 = (t0 + 2696);
    t7 = (t1 + 32U);
    t9 = *((char **)t7);
    t10 = (t9 + 40U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(69, ng0);
    t1 = (t0 + 2660);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t7 = (t4 + 40U);
    t9 = *((char **)t7);
    *((unsigned char *)t9) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB9;

LAB11:    t1 = (t0 + 724U);
    t4 = *((char **)t1);
    t8 = *((unsigned char *)t4);
    t13 = (t8 == (unsigned char)2);
    t2 = t13;
    goto LAB13;

}

static void work_a_1774854872_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    int t11;
    int t12;
    int t13;
    char *t14;
    int t16;
    char *t17;
    int t19;
    char *t20;
    int t22;
    char *t23;
    int t25;
    char *t26;
    int t28;
    char *t29;
    int t31;
    char *t32;
    int t34;
    char *t35;
    int t37;
    char *t38;
    int t40;
    char *t41;
    int t43;
    char *t44;
    int t46;
    char *t47;
    int t49;
    char *t50;
    int t52;
    char *t53;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    char *t59;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;

LAB0:    xsi_set_current_line(79, ng0);
    t1 = (t0 + 636U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 1320U);
    t3 = p_2592010699_sub_1744673427_2592010699(IEEE_P_2592010699, t1, 0U, 0U);
    if (t3 != 0)
        goto LAB5;

LAB6:
LAB3:    xsi_set_current_line(105, ng0);
    t1 = (t0 + 4484);
    t5 = (t0 + 2768);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 4U);
    xsi_driver_first_trans_fast_port(t5);
    xsi_set_current_line(107, ng0);
    t1 = (t0 + 1428U);
    t2 = *((char **)t1);
    t60 = (7 - 7);
    t61 = (t60 * 1U);
    t62 = (0 + t61);
    t1 = (t2 + t62);
    t5 = (t0 + 2804);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    t1 = (t0 + 2616);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(81, ng0);
    t1 = (t0 + 4212);
    t6 = (t0 + 2732);
    t7 = (t6 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 8U);
    xsi_driver_first_trans_delta(t6, 0U, 8U, 0LL);
    goto LAB3;

LAB5:    xsi_set_current_line(85, ng0);
    t2 = (t0 + 1516U);
    t5 = *((char **)t2);
    t2 = (t0 + 4220);
    t11 = xsi_mem_cmp(t2, t5, 8U);
    if (t11 == 1)
        goto LAB8;

LAB25:    t7 = (t0 + 4228);
    t12 = xsi_mem_cmp(t7, t5, 8U);
    if (t12 == 1)
        goto LAB9;

LAB26:    t9 = (t0 + 4236);
    t13 = xsi_mem_cmp(t9, t5, 8U);
    if (t13 == 1)
        goto LAB10;

LAB27:    t14 = (t0 + 4244);
    t16 = xsi_mem_cmp(t14, t5, 8U);
    if (t16 == 1)
        goto LAB11;

LAB28:    t17 = (t0 + 4252);
    t19 = xsi_mem_cmp(t17, t5, 8U);
    if (t19 == 1)
        goto LAB12;

LAB29:    t20 = (t0 + 4260);
    t22 = xsi_mem_cmp(t20, t5, 8U);
    if (t22 == 1)
        goto LAB13;

LAB30:    t23 = (t0 + 4268);
    t25 = xsi_mem_cmp(t23, t5, 8U);
    if (t25 == 1)
        goto LAB14;

LAB31:    t26 = (t0 + 4276);
    t28 = xsi_mem_cmp(t26, t5, 8U);
    if (t28 == 1)
        goto LAB15;

LAB32:    t29 = (t0 + 4284);
    t31 = xsi_mem_cmp(t29, t5, 8U);
    if (t31 == 1)
        goto LAB16;

LAB33:    t32 = (t0 + 4292);
    t34 = xsi_mem_cmp(t32, t5, 8U);
    if (t34 == 1)
        goto LAB17;

LAB34:    t35 = (t0 + 4300);
    t37 = xsi_mem_cmp(t35, t5, 8U);
    if (t37 == 1)
        goto LAB18;

LAB35:    t38 = (t0 + 4308);
    t40 = xsi_mem_cmp(t38, t5, 8U);
    if (t40 == 1)
        goto LAB19;

LAB36:    t41 = (t0 + 4316);
    t43 = xsi_mem_cmp(t41, t5, 8U);
    if (t43 == 1)
        goto LAB20;

LAB37:    t44 = (t0 + 4324);
    t46 = xsi_mem_cmp(t44, t5, 8U);
    if (t46 == 1)
        goto LAB21;

LAB38:    t47 = (t0 + 4332);
    t49 = xsi_mem_cmp(t47, t5, 8U);
    if (t49 == 1)
        goto LAB22;

LAB39:    t50 = (t0 + 4340);
    t52 = xsi_mem_cmp(t50, t5, 8U);
    if (t52 == 1)
        goto LAB23;

LAB40:
LAB24:    xsi_set_current_line(102, ng0);
    t1 = (t0 + 4476);
    t5 = (t0 + 2732);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);

LAB7:    goto LAB3;

LAB8:    xsi_set_current_line(86, ng0);
    t53 = (t0 + 4348);
    t55 = (t0 + 2732);
    t56 = (t55 + 32U);
    t57 = *((char **)t56);
    t58 = (t57 + 40U);
    t59 = *((char **)t58);
    memcpy(t59, t53, 8U);
    xsi_driver_first_trans_delta(t55, 0U, 8U, 0LL);
    goto LAB7;

LAB9:    xsi_set_current_line(87, ng0);
    t1 = (t0 + 4356);
    t5 = (t0 + 2732);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB7;

LAB10:    xsi_set_current_line(88, ng0);
    t1 = (t0 + 4364);
    t5 = (t0 + 2732);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB7;

LAB11:    xsi_set_current_line(89, ng0);
    t1 = (t0 + 4372);
    t5 = (t0 + 2732);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB7;

LAB12:    xsi_set_current_line(90, ng0);
    t1 = (t0 + 4380);
    t5 = (t0 + 2732);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB7;

LAB13:    xsi_set_current_line(91, ng0);
    t1 = (t0 + 4388);
    t5 = (t0 + 2732);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB7;

LAB14:    xsi_set_current_line(92, ng0);
    t1 = (t0 + 4396);
    t5 = (t0 + 2732);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB7;

LAB15:    xsi_set_current_line(93, ng0);
    t1 = (t0 + 4404);
    t5 = (t0 + 2732);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB7;

LAB16:    xsi_set_current_line(94, ng0);
    t1 = (t0 + 4412);
    t5 = (t0 + 2732);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB7;

LAB17:    xsi_set_current_line(95, ng0);
    t1 = (t0 + 4420);
    t5 = (t0 + 2732);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB7;

LAB18:    xsi_set_current_line(96, ng0);
    t1 = (t0 + 4428);
    t5 = (t0 + 2732);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB7;

LAB19:    xsi_set_current_line(97, ng0);
    t1 = (t0 + 4436);
    t5 = (t0 + 2732);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB7;

LAB20:    xsi_set_current_line(98, ng0);
    t1 = (t0 + 4444);
    t5 = (t0 + 2732);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB7;

LAB21:    xsi_set_current_line(99, ng0);
    t1 = (t0 + 4452);
    t5 = (t0 + 2732);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB7;

LAB22:    xsi_set_current_line(100, ng0);
    t1 = (t0 + 4460);
    t5 = (t0 + 2732);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB7;

LAB23:    xsi_set_current_line(101, ng0);
    t1 = (t0 + 4468);
    t5 = (t0 + 2732);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB7;

LAB41:;
}


extern void work_a_1774854872_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1774854872_3212880686_p_0,(void *)work_a_1774854872_3212880686_p_1};
	xsi_register_didat("work_a_1774854872_3212880686", "isim/_tmp/work/a_1774854872_3212880686.didat");
	xsi_register_executes(pe);
}
