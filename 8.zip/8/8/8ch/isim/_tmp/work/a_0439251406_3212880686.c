/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                         */
/*  \   \        Copyright (c) 2003-2007 Xilinx, Inc.                 */
/*  /   /        All Right Reserved.                                  */
/* /---/   /\                                                         */
/* \   \  /  \                                                        */
/*  \___\/\___\                                                       */
/**********************************************************************/

/* This file is designed for use with ISim build 0x734844ce */

#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/studia/Sem4/IUP/8/8ch/disp.vhd";
extern char *IEEE_P_2592010699;

unsigned char p_2592010699_sub_1744673427_2592010699(char *, char *, unsigned int , unsigned int );


static void work_a_0439251406_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    int t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;

LAB0:    xsi_set_current_line(47, ng0);
    t1 = (t0 + 900U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 792U);
    t3 = p_2592010699_sub_1744673427_2592010699(IEEE_P_2592010699, t1, 0U, 0U);
    if (t3 != 0)
        goto LAB8;

LAB9:
LAB3:    t1 = (t0 + 1752);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(48, ng0);
    t1 = (t0 + 1064U);
    t5 = *((char **)t1);
    t6 = *((int *)t5);

LAB6:    xsi_set_current_line(49, ng0);

LAB5:    goto LAB3;

LAB7:;
LAB8:    xsi_set_current_line(52, ng0);
    t2 = (t0 + 1064U);
    t5 = *((char **)t2);
    t6 = *((int *)t5);
    if (t6 == 0)
        goto LAB11;

LAB16:    if (t6 == 1)
        goto LAB12;

LAB17:    if (t6 == 2)
        goto LAB13;

LAB18:    if (t6 == 3)
        goto LAB14;

LAB19:
LAB15:    xsi_set_current_line(69, ng0);

LAB10:    goto LAB3;

LAB11:    xsi_set_current_line(54, ng0);
    t2 = (t0 + 724U);
    t7 = *((char **)t2);
    t8 = (31 - 7);
    t9 = (t8 * 1U);
    t10 = (0 + t9);
    t2 = (t7 + t10);
    t11 = (t0 + 1796);
    t12 = (t11 + 32U);
    t13 = *((char **)t12);
    t14 = (t13 + 40U);
    t15 = *((char **)t14);
    memcpy(t15, t2, 8U);
    xsi_driver_first_trans_delta(t11, 0U, 8U, 0LL);
    xsi_set_current_line(55, ng0);
    t1 = (t0 + 2964);
    t5 = (t0 + 1832);
    t7 = (t5 + 32U);
    t11 = *((char **)t7);
    t12 = (t11 + 40U);
    t13 = *((char **)t12);
    memcpy(t13, t1, 4U);
    xsi_driver_first_trans_delta(t5, 0U, 4U, 0LL);
    xsi_set_current_line(56, ng0);
    t1 = (t0 + 1064U);
    t2 = *((char **)t1);
    t1 = (t2 + 0);
    *((int *)t1) = 1;
    t5 = (t0 + 1032U);
    xsi_variable_act(t5);
    goto LAB10;

LAB12:    xsi_set_current_line(58, ng0);
    t1 = (t0 + 724U);
    t2 = *((char **)t1);
    t8 = (31 - 15);
    t9 = (t8 * 1U);
    t10 = (0 + t9);
    t1 = (t2 + t10);
    t5 = (t0 + 1796);
    t7 = (t5 + 32U);
    t11 = *((char **)t7);
    t12 = (t11 + 40U);
    t13 = *((char **)t12);
    memcpy(t13, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    xsi_set_current_line(59, ng0);
    t1 = (t0 + 2968);
    t5 = (t0 + 1832);
    t7 = (t5 + 32U);
    t11 = *((char **)t7);
    t12 = (t11 + 40U);
    t13 = *((char **)t12);
    memcpy(t13, t1, 4U);
    xsi_driver_first_trans_delta(t5, 0U, 4U, 0LL);
    xsi_set_current_line(60, ng0);
    t1 = (t0 + 1064U);
    t2 = *((char **)t1);
    t1 = (t2 + 0);
    *((int *)t1) = 2;
    t5 = (t0 + 1032U);
    xsi_variable_act(t5);
    goto LAB10;

LAB13:    xsi_set_current_line(62, ng0);
    t1 = (t0 + 724U);
    t2 = *((char **)t1);
    t8 = (31 - 23);
    t9 = (t8 * 1U);
    t10 = (0 + t9);
    t1 = (t2 + t10);
    t5 = (t0 + 1796);
    t7 = (t5 + 32U);
    t11 = *((char **)t7);
    t12 = (t11 + 40U);
    t13 = *((char **)t12);
    memcpy(t13, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    xsi_set_current_line(63, ng0);
    t1 = (t0 + 2972);
    t5 = (t0 + 1832);
    t7 = (t5 + 32U);
    t11 = *((char **)t7);
    t12 = (t11 + 40U);
    t13 = *((char **)t12);
    memcpy(t13, t1, 4U);
    xsi_driver_first_trans_delta(t5, 0U, 4U, 0LL);
    xsi_set_current_line(64, ng0);
    t1 = (t0 + 1064U);
    t2 = *((char **)t1);
    t1 = (t2 + 0);
    *((int *)t1) = 3;
    t5 = (t0 + 1032U);
    xsi_variable_act(t5);
    goto LAB10;

LAB14:    xsi_set_current_line(66, ng0);
    t1 = (t0 + 724U);
    t2 = *((char **)t1);
    t8 = (31 - 31);
    t9 = (t8 * 1U);
    t10 = (0 + t9);
    t1 = (t2 + t10);
    t5 = (t0 + 1796);
    t7 = (t5 + 32U);
    t11 = *((char **)t7);
    t12 = (t11 + 40U);
    t13 = *((char **)t12);
    memcpy(t13, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    xsi_set_current_line(67, ng0);
    t1 = (t0 + 2976);
    t5 = (t0 + 1832);
    t7 = (t5 + 32U);
    t11 = *((char **)t7);
    t12 = (t11 + 40U);
    t13 = *((char **)t12);
    memcpy(t13, t1, 4U);
    xsi_driver_first_trans_delta(t5, 0U, 4U, 0LL);
    xsi_set_current_line(68, ng0);
    t1 = (t0 + 1064U);
    t2 = *((char **)t1);
    t1 = (t2 + 0);
    *((int *)t1) = 0;
    t5 = (t0 + 1032U);
    xsi_variable_act(t5);
    goto LAB10;

LAB20:;
}


extern void work_a_0439251406_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0439251406_3212880686_p_0};
	xsi_register_didat("work_a_0439251406_3212880686", "isim/_tmp/work/a_0439251406_3212880686.didat");
	xsi_register_executes(pe);
}
