/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                         */
/*  \   \        Copyright (c) 2003-2007 Xilinx, Inc.                 */
/*  /   /        All Right Reserved.                                  */
/* /---/   /\                                                         */
/* \   \  /  \                                                        */
/*  \___\/\___\                                                       */
/**********************************************************************/

/* This file is designed for use with ISim build 0x734844ce */

#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/studia/Sem4/IUP/8/8ch/PS2_READ.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_3620187407;

unsigned char ieee_std_logic_unsigned_equal_stdv_stdv(char *, char *, char *, char *, char *);
unsigned char p_2592010699_sub_1258338084_2592010699(char *, char *, unsigned int , unsigned int );
unsigned char p_2592010699_sub_2507238156_2592010699(char *, unsigned char , unsigned char );
unsigned char p_3620187407_sub_3975909357_3620187407(char *, char *, char *, char *, char *);


static void work_a_1850669875_3212880686_p_0(char *t0)
{
    char t69[16];
    char t70[16];
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    int t5;
    unsigned char t6;
    char *t7;
    unsigned char t8;
    unsigned char t9;
    char *t10;
    int t11;
    char *t12;
    int t13;
    int t14;
    int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned char t26;
    unsigned char t27;
    char *t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned char t33;
    unsigned char t34;
    char *t35;
    char *t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned char t40;
    unsigned char t41;
    char *t42;
    char *t43;
    int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned char t48;
    unsigned char t49;
    char *t50;
    char *t51;
    int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned char t56;
    unsigned char t57;
    char *t58;
    char *t59;
    int t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    unsigned char t64;
    unsigned char t65;
    unsigned char t66;
    char *t67;
    char *t68;

LAB0:    xsi_set_current_line(43, ng0);
    t1 = (t0 + 616U);
    t2 = p_2592010699_sub_1258338084_2592010699(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 1984);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(45, ng0);
    t3 = (t0 + 976U);
    t4 = *((char **)t3);
    t5 = *((int *)t4);
    t6 = (t5 == 0);
    if (t6 != 0)
        goto LAB5;

LAB7:    t1 = (t0 + 976U);
    t3 = *((char **)t1);
    t5 = *((int *)t3);
    t6 = (t5 >= 1);
    if (t6 == 1)
        goto LAB13;

LAB14:    t2 = (unsigned char)0;

LAB15:    if (t2 != 0)
        goto LAB11;

LAB12:    t1 = (t0 + 976U);
    t3 = *((char **)t1);
    t5 = *((int *)t3);
    t2 = (t5 == 9);
    if (t2 != 0)
        goto LAB16;

LAB17:    t1 = (t0 + 976U);
    t3 = *((char **)t1);
    t5 = *((int *)t3);
    t2 = (t5 == 10);
    if (t2 != 0)
        goto LAB18;

LAB19:
LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(47, ng0);
    t3 = (t0 + 548U);
    t7 = *((char **)t3);
    t8 = *((unsigned char *)t7);
    t9 = (t8 == (unsigned char)2);
    if (t9 != 0)
        goto LAB8;

LAB10:
LAB9:    goto LAB6;

LAB8:    xsi_set_current_line(48, ng0);
    t3 = (t0 + 976U);
    t10 = *((char **)t3);
    t3 = (t10 + 0);
    *((int *)t3) = 1;
    goto LAB9;

LAB11:    xsi_set_current_line(53, ng0);
    t1 = (t0 + 548U);
    t7 = *((char **)t1);
    t9 = *((unsigned char *)t7);
    t1 = (t0 + 1040U);
    t10 = *((char **)t1);
    t1 = (t0 + 976U);
    t12 = *((char **)t1);
    t13 = *((int *)t12);
    t14 = (t13 - 1);
    t15 = (t14 - 7);
    t16 = (t15 * -1);
    xsi_vhdl_check_range_of_index(7, 0, -1, t14);
    t17 = (1U * t16);
    t18 = (0 + t17);
    t1 = (t10 + t18);
    *((unsigned char *)t1) = t9;
    xsi_set_current_line(54, ng0);
    t1 = (t0 + 976U);
    t3 = *((char **)t1);
    t5 = *((int *)t3);
    t11 = (t5 + 1);
    t1 = (t0 + 976U);
    t4 = *((char **)t1);
    t1 = (t4 + 0);
    *((int *)t1) = t11;
    goto LAB6;

LAB13:    t1 = (t0 + 976U);
    t4 = *((char **)t1);
    t11 = *((int *)t4);
    t8 = (t11 <= 8);
    t2 = t8;
    goto LAB15;

LAB16:    xsi_set_current_line(58, ng0);
    t1 = (t0 + 548U);
    t4 = *((char **)t1);
    t6 = *((unsigned char *)t4);
    t1 = (t0 + 2028);
    t7 = (t1 + 32U);
    t10 = *((char **)t7);
    t12 = (t10 + 40U);
    t19 = *((char **)t12);
    *((unsigned char *)t19) = t6;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(59, ng0);
    t1 = (t0 + 976U);
    t3 = *((char **)t1);
    t5 = *((int *)t3);
    t11 = (t5 + 1);
    t1 = (t0 + 976U);
    t4 = *((char **)t1);
    t1 = (t4 + 0);
    *((int *)t1) = t11;
    goto LAB6;

LAB18:    xsi_set_current_line(63, ng0);
    t1 = (t0 + 976U);
    t4 = *((char **)t1);
    t1 = (t4 + 0);
    *((int *)t1) = 0;
    xsi_set_current_line(72, ng0);
    t1 = (t0 + 812U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t1 = (t0 + 1040U);
    t4 = *((char **)t1);
    t5 = (0 - 7);
    t16 = (t5 * -1);
    t17 = (1U * t16);
    t18 = (0 + t17);
    t1 = (t4 + t18);
    t6 = *((unsigned char *)t1);
    t7 = (t0 + 1040U);
    t10 = *((char **)t7);
    t11 = (1 - 7);
    t20 = (t11 * -1);
    t21 = (1U * t20);
    t22 = (0 + t21);
    t7 = (t10 + t22);
    t8 = *((unsigned char *)t7);
    t9 = p_2592010699_sub_2507238156_2592010699(IEEE_P_2592010699, t6, t8);
    t12 = (t0 + 1040U);
    t19 = *((char **)t12);
    t13 = (2 - 7);
    t23 = (t13 * -1);
    t24 = (1U * t23);
    t25 = (0 + t24);
    t12 = (t19 + t25);
    t26 = *((unsigned char *)t12);
    t27 = p_2592010699_sub_2507238156_2592010699(IEEE_P_2592010699, t9, t26);
    t28 = (t0 + 1040U);
    t29 = *((char **)t28);
    t14 = (3 - 7);
    t30 = (t14 * -1);
    t31 = (1U * t30);
    t32 = (0 + t31);
    t28 = (t29 + t32);
    t33 = *((unsigned char *)t28);
    t34 = p_2592010699_sub_2507238156_2592010699(IEEE_P_2592010699, t27, t33);
    t35 = (t0 + 1040U);
    t36 = *((char **)t35);
    t15 = (4 - 7);
    t37 = (t15 * -1);
    t38 = (1U * t37);
    t39 = (0 + t38);
    t35 = (t36 + t39);
    t40 = *((unsigned char *)t35);
    t41 = p_2592010699_sub_2507238156_2592010699(IEEE_P_2592010699, t34, t40);
    t42 = (t0 + 1040U);
    t43 = *((char **)t42);
    t44 = (5 - 7);
    t45 = (t44 * -1);
    t46 = (1U * t45);
    t47 = (0 + t46);
    t42 = (t43 + t47);
    t48 = *((unsigned char *)t42);
    t49 = p_2592010699_sub_2507238156_2592010699(IEEE_P_2592010699, t41, t48);
    t50 = (t0 + 1040U);
    t51 = *((char **)t50);
    t52 = (6 - 7);
    t53 = (t52 * -1);
    t54 = (1U * t53);
    t55 = (0 + t54);
    t50 = (t51 + t55);
    t56 = *((unsigned char *)t50);
    t57 = p_2592010699_sub_2507238156_2592010699(IEEE_P_2592010699, t49, t56);
    t58 = (t0 + 1040U);
    t59 = *((char **)t58);
    t60 = (7 - 7);
    t61 = (t60 * -1);
    t62 = (1U * t61);
    t63 = (0 + t62);
    t58 = (t59 + t63);
    t64 = *((unsigned char *)t58);
    t65 = p_2592010699_sub_2507238156_2592010699(IEEE_P_2592010699, t57, t64);
    t66 = (t2 != t65);
    if (t66 != 0)
        goto LAB20;

LAB22:
LAB21:    xsi_set_current_line(78, ng0);
    t1 = (t0 + 1104U);
    t3 = *((char **)t1);
    t5 = *((int *)t3);
    t2 = (t5 == 1);
    if (t2 != 0)
        goto LAB23;

LAB25:
LAB24:    goto LAB6;

LAB20:    xsi_set_current_line(73, ng0);
    t67 = (t0 + 1104U);
    t68 = *((char **)t67);
    t67 = (t68 + 0);
    *((int *)t67) = 1;
    goto LAB21;

LAB23:    xsi_set_current_line(79, ng0);
    t1 = (t0 + 1104U);
    t4 = *((char **)t1);
    t1 = (t4 + 0);
    *((int *)t1) = 0;
    xsi_set_current_line(81, ng0);
    t1 = (t0 + 1040U);
    t3 = *((char **)t1);
    t16 = (7 - 7);
    t17 = (t16 * 1U);
    t18 = (0 + t17);
    t1 = (t3 + t18);
    t4 = (t69 + 0U);
    t7 = (t4 + 0U);
    *((int *)t7) = 7;
    t7 = (t4 + 4U);
    *((int *)t7) = 0;
    t7 = (t4 + 8U);
    *((int *)t7) = -1;
    t5 = (0 - 7);
    t20 = (t5 * -1);
    t20 = (t20 + 1);
    t7 = (t4 + 12U);
    *((unsigned int *)t7) = t20;
    t7 = (t0 + 3236);
    t12 = (t70 + 0U);
    t19 = (t12 + 0U);
    *((int *)t19) = 0;
    t19 = (t12 + 4U);
    *((int *)t19) = 7;
    t19 = (t12 + 8U);
    *((int *)t19) = 1;
    t11 = (7 - 0);
    t20 = (t11 * 1);
    t20 = (t20 + 1);
    t19 = (t12 + 12U);
    *((unsigned int *)t19) = t20;
    t2 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t1, t69, t7, t70);
    if (t2 != 0)
        goto LAB26;

LAB28:    t1 = (t0 + 1040U);
    t3 = *((char **)t1);
    t1 = (t0 + 3168U);
    t4 = (t0 + 3244);
    t10 = (t69 + 0U);
    t12 = (t10 + 0U);
    *((int *)t12) = 0;
    t12 = (t10 + 4U);
    *((int *)t12) = 7;
    t12 = (t10 + 8U);
    *((int *)t12) = 1;
    t5 = (7 - 0);
    t16 = (t5 * 1);
    t16 = (t16 + 1);
    t12 = (t10 + 12U);
    *((unsigned int *)t12) = t16;
    t2 = p_3620187407_sub_3975909357_3620187407(IEEE_P_3620187407, t3, t1, t4, t69);
    if (t2 != 0)
        goto LAB29;

LAB30:
LAB27:    goto LAB24;

LAB26:    xsi_set_current_line(82, ng0);
    t19 = (t0 + 1232U);
    t28 = *((char **)t19);
    t19 = (t0 + 2064);
    t29 = (t19 + 32U);
    t35 = *((char **)t29);
    t36 = (t35 + 40U);
    t42 = *((char **)t36);
    memcpy(t42, t28, 8U);
    xsi_driver_first_trans_fast_port(t19);
    goto LAB27;

LAB29:    xsi_set_current_line(84, ng0);
    t12 = (t0 + 3252);
    *((int *)t12) = 7;
    t19 = (t0 + 3256);
    *((int *)t19) = 0;
    t11 = 7;
    t13 = 0;

LAB31:    if (t11 >= t13)
        goto LAB32;

LAB34:    xsi_set_current_line(87, ng0);
    t1 = (t0 + 1040U);
    t3 = *((char **)t1);
    t1 = (t0 + 2064);
    t4 = (t1 + 32U);
    t7 = *((char **)t4);
    t10 = (t7 + 40U);
    t12 = *((char **)t10);
    memcpy(t12, t3, 8U);
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(88, ng0);
    t1 = (t0 + 1040U);
    t3 = *((char **)t1);
    t1 = (t0 + 1232U);
    t4 = *((char **)t1);
    t1 = (t4 + 0);
    memcpy(t1, t3, 8U);
    goto LAB27;

LAB32:    xsi_set_current_line(85, ng0);
    t28 = (t0 + 1040U);
    t29 = *((char **)t28);
    t28 = (t0 + 3252);
    t14 = *((int *)t28);
    t15 = (t14 - 7);
    t16 = (t15 * -1);
    t17 = (1U * t16);
    t18 = (0 + t17);
    t35 = (t29 + t18);
    t6 = *((unsigned char *)t35);
    t36 = (t0 + 3252);
    t44 = *((int *)t36);
    t52 = (7 - t44);
    t60 = (t52 - 7);
    t20 = (t60 * -1);
    t21 = (1 * t20);
    t22 = (0U + t21);
    t42 = (t0 + 2064);
    t43 = (t42 + 32U);
    t50 = *((char **)t43);
    t51 = (t50 + 40U);
    t58 = *((char **)t51);
    *((unsigned char *)t58) = t6;
    xsi_driver_first_trans_delta(t42, t22, 1, 0LL);

LAB33:    t1 = (t0 + 3252);
    t11 = *((int *)t1);
    t3 = (t0 + 3256);
    t13 = *((int *)t3);
    t5 = (t11 + -1);
    t11 = t5;
    t4 = (t0 + 3252);
    *((int *)t4) = t11;
    goto LAB31;

}


extern void work_a_1850669875_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1850669875_3212880686_p_0};
	xsi_register_didat("work_a_1850669875_3212880686", "isim/_tmp/work/a_1850669875_3212880686.didat");
	xsi_register_executes(pe);
}
