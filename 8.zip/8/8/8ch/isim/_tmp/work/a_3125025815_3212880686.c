/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                         */
/*  \   \        Copyright (c) 2003-2007 Xilinx, Inc.                 */
/*  /   /        All Right Reserved.                                  */
/* /---/   /\                                                         */
/* \   \  /  \                                                        */
/*  \___\/\___\                                                       */
/**********************************************************************/

/* This file is designed for use with ISim build 0x734844ce */

#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/studia/Sem4/IUP/8/8ch/clk_div.vhd";
extern char *IEEE_P_2592010699;

unsigned char p_2592010699_sub_1744673427_2592010699(char *, char *, unsigned int , unsigned int );


static void work_a_3125025815_3212880686_p_0(char *t0)
{
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    int t5;
    char *t6;
    int t7;
    int t8;
    unsigned char t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    int t14;
    int t15;
    unsigned char t16;
    char *t17;

LAB0:    xsi_set_current_line(44, ng0);
    t1 = (t0 + 528U);
    t2 = p_2592010699_sub_1744673427_2592010699(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 1552);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(46, ng0);
    t3 = (t0 + 864U);
    t4 = *((char **)t3);
    t5 = *((int *)t4);
    t3 = (t0 + 800U);
    t6 = *((char **)t3);
    t7 = *((int *)t6);
    t8 = (t7 / 2);
    t9 = (t5 < t8);
    if (t9 != 0)
        goto LAB5;

LAB7:    t1 = (t0 + 864U);
    t3 = *((char **)t1);
    t5 = *((int *)t3);
    t1 = (t0 + 800U);
    t4 = *((char **)t1);
    t7 = *((int *)t4);
    t8 = (t7 / 2);
    t9 = (t5 >= t8);
    if (t9 == 1)
        goto LAB10;

LAB11:    t2 = (unsigned char)0;

LAB12:    if (t2 != 0)
        goto LAB8;

LAB9:    t1 = (t0 + 864U);
    t3 = *((char **)t1);
    t5 = *((int *)t3);
    t1 = (t0 + 800U);
    t4 = *((char **)t1);
    t7 = *((int *)t4);
    t2 = (t5 >= t7);
    if (t2 != 0)
        goto LAB13;

LAB14:
LAB6:    xsi_set_current_line(54, ng0);
    t1 = (t0 + 864U);
    t3 = *((char **)t1);
    t5 = *((int *)t3);
    t7 = (t5 + 1);
    t1 = (t0 + 864U);
    t4 = *((char **)t1);
    t1 = (t4 + 0);
    *((int *)t1) = t7;
    t6 = (t0 + 832U);
    xsi_variable_act(t6);
    goto LAB3;

LAB5:    xsi_set_current_line(47, ng0);
    t3 = (t0 + 1596);
    t10 = (t3 + 32U);
    t11 = *((char **)t10);
    t12 = (t11 + 40U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t3);
    goto LAB6;

LAB8:    xsi_set_current_line(49, ng0);
    t1 = (t0 + 1596);
    t11 = (t1 + 32U);
    t12 = *((char **)t11);
    t13 = (t12 + 40U);
    t17 = *((char **)t13);
    *((unsigned char *)t17) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB6;

LAB10:    t1 = (t0 + 864U);
    t6 = *((char **)t1);
    t14 = *((int *)t6);
    t1 = (t0 + 800U);
    t10 = *((char **)t1);
    t15 = *((int *)t10);
    t16 = (t14 < t15);
    t2 = t16;
    goto LAB12;

LAB13:    xsi_set_current_line(51, ng0);
    t1 = (t0 + 1596);
    t6 = (t1 + 32U);
    t10 = *((char **)t6);
    t11 = (t10 + 40U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(52, ng0);
    t1 = (t0 + 864U);
    t3 = *((char **)t1);
    t1 = (t3 + 0);
    *((int *)t1) = 0;
    t4 = (t0 + 832U);
    xsi_variable_act(t4);
    goto LAB6;

}


extern void work_a_3125025815_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3125025815_3212880686_p_0};
	xsi_register_didat("work_a_3125025815_3212880686", "isim/_tmp/work/a_3125025815_3212880686.didat");
	xsi_register_executes(pe);
}
