/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                         */
/*  \   \        Copyright (c) 2003-2007 Xilinx, Inc.                 */
/*  /   /        All Right Reserved.                                  */
/* /---/   /\                                                         */
/* \   \  /  \                                                        */
/*  \___\/\___\                                                       */
/**********************************************************************/

/* This file is designed for use with ISim build 0x734844ce */

#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/studia/Sem4/IUP/8/P8/main.vhd";
extern char *IEEE_P_2592010699;

unsigned char p_2592010699_sub_1744673427_2592010699(char *, char *, unsigned int , unsigned int );


static void work_a_1774854872_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    unsigned char t13;
    int t14;
    int t15;
    int t16;
    int t18;
    char *t19;
    int t21;
    char *t22;
    int t24;
    char *t25;
    int t27;
    char *t28;
    int t30;
    char *t31;
    int t33;
    char *t34;
    int t36;
    char *t37;
    int t39;
    char *t40;
    int t42;
    char *t43;
    int t45;
    char *t46;
    int t48;
    char *t49;
    int t51;
    char *t52;
    int t54;
    char *t55;
    char *t57;
    char *t58;
    char *t59;
    char *t60;
    char *t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;

LAB0:    xsi_set_current_line(72, ng0);
    t1 = (t0 + 636U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 528U);
    t3 = p_2592010699_sub_1744673427_2592010699(IEEE_P_2592010699, t1, 0U, 0U);
    if (t3 != 0)
        goto LAB5;

LAB6:
LAB3:    xsi_set_current_line(92, ng0);
    t1 = (t0 + 548U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 2808);
    t5 = (t1 + 32U);
    t6 = *((char **)t5);
    t7 = (t6 + 40U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(95, ng0);
    t1 = (t0 + 1516U);
    t2 = *((char **)t1);
    t1 = (t0 + 4408);
    t14 = xsi_mem_cmp(t1, t2, 8U);
    if (t14 == 1)
        goto LAB17;

LAB34:    t6 = (t0 + 4416);
    t15 = xsi_mem_cmp(t6, t2, 8U);
    if (t15 == 1)
        goto LAB18;

LAB35:    t8 = (t0 + 4424);
    t16 = xsi_mem_cmp(t8, t2, 8U);
    if (t16 == 1)
        goto LAB19;

LAB36:    t10 = (t0 + 4432);
    t18 = xsi_mem_cmp(t10, t2, 8U);
    if (t18 == 1)
        goto LAB20;

LAB37:    t19 = (t0 + 4440);
    t21 = xsi_mem_cmp(t19, t2, 8U);
    if (t21 == 1)
        goto LAB21;

LAB38:    t22 = (t0 + 4448);
    t24 = xsi_mem_cmp(t22, t2, 8U);
    if (t24 == 1)
        goto LAB22;

LAB39:    t25 = (t0 + 4456);
    t27 = xsi_mem_cmp(t25, t2, 8U);
    if (t27 == 1)
        goto LAB23;

LAB40:    t28 = (t0 + 4464);
    t30 = xsi_mem_cmp(t28, t2, 8U);
    if (t30 == 1)
        goto LAB24;

LAB41:    t31 = (t0 + 4472);
    t33 = xsi_mem_cmp(t31, t2, 8U);
    if (t33 == 1)
        goto LAB25;

LAB42:    t34 = (t0 + 4480);
    t36 = xsi_mem_cmp(t34, t2, 8U);
    if (t36 == 1)
        goto LAB26;

LAB43:    t37 = (t0 + 4488);
    t39 = xsi_mem_cmp(t37, t2, 8U);
    if (t39 == 1)
        goto LAB27;

LAB44:    t40 = (t0 + 4496);
    t42 = xsi_mem_cmp(t40, t2, 8U);
    if (t42 == 1)
        goto LAB28;

LAB45:    t43 = (t0 + 4504);
    t45 = xsi_mem_cmp(t43, t2, 8U);
    if (t45 == 1)
        goto LAB29;

LAB46:    t46 = (t0 + 4512);
    t48 = xsi_mem_cmp(t46, t2, 8U);
    if (t48 == 1)
        goto LAB30;

LAB47:    t49 = (t0 + 4520);
    t51 = xsi_mem_cmp(t49, t2, 8U);
    if (t51 == 1)
        goto LAB31;

LAB48:    t52 = (t0 + 4528);
    t54 = xsi_mem_cmp(t52, t2, 8U);
    if (t54 == 1)
        goto LAB32;

LAB49:
LAB33:    xsi_set_current_line(112, ng0);

LAB16:    xsi_set_current_line(115, ng0);
    t1 = (t0 + 1780U);
    t2 = *((char **)t1);
    t1 = (t0 + 2844);
    t5 = (t1 + 32U);
    t6 = *((char **)t5);
    t7 = (t6 + 40U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 4U);
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(117, ng0);
    t1 = (t0 + 1604U);
    t2 = *((char **)t1);
    t62 = (7 - 7);
    t63 = (t62 * 1U);
    t64 = (0 + t63);
    t1 = (t2 + t64);
    t5 = (t0 + 2880);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    t1 = (t0 + 2656);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(74, ng0);
    t1 = (t0 + 4400);
    t6 = (t0 + 2700);
    t7 = (t6 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 8U);
    xsi_driver_first_trans_delta(t6, 0U, 8U, 0LL);
    goto LAB3;

LAB5:    xsi_set_current_line(78, ng0);
    t2 = (t0 + 1428U);
    t5 = *((char **)t2);
    t4 = *((unsigned char *)t5);
    t11 = (t4 == (unsigned char)3);
    if (t11 != 0)
        goto LAB7;

LAB9:
LAB8:    xsi_set_current_line(82, ng0);
    t1 = (t0 + 1076U);
    t2 = *((char **)t1);
    t4 = *((unsigned char *)t2);
    t11 = (t4 == (unsigned char)3);
    if (t11 == 1)
        goto LAB13;

LAB14:    t3 = (unsigned char)0;

LAB15:    if (t3 != 0)
        goto LAB10;

LAB12:    xsi_set_current_line(86, ng0);
    t1 = (t0 + 2772);
    t2 = (t1 + 32U);
    t5 = *((char **)t2);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB11:    goto LAB3;

LAB7:    xsi_set_current_line(79, ng0);
    t2 = (t0 + 1428U);
    t6 = *((char **)t2);
    t12 = *((unsigned char *)t6);
    t2 = (t0 + 2736);
    t7 = (t2 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    *((unsigned char *)t10) = t12;
    xsi_driver_first_trans_fast(t2);
    goto LAB8;

LAB10:    xsi_set_current_line(83, ng0);
    t1 = (t0 + 2772);
    t6 = (t1 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(84, ng0);
    t1 = (t0 + 2736);
    t2 = (t1 + 32U);
    t5 = *((char **)t2);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB11;

LAB13:    t1 = (t0 + 1428U);
    t5 = *((char **)t1);
    t12 = *((unsigned char *)t5);
    t13 = (t12 == (unsigned char)2);
    t3 = t13;
    goto LAB15;

LAB17:    xsi_set_current_line(96, ng0);
    t55 = (t0 + 4536);
    t57 = (t0 + 2700);
    t58 = (t57 + 32U);
    t59 = *((char **)t58);
    t60 = (t59 + 40U);
    t61 = *((char **)t60);
    memcpy(t61, t55, 8U);
    xsi_driver_first_trans_delta(t57, 0U, 8U, 0LL);
    goto LAB16;

LAB18:    xsi_set_current_line(97, ng0);
    t1 = (t0 + 4544);
    t5 = (t0 + 2700);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB16;

LAB19:    xsi_set_current_line(98, ng0);
    t1 = (t0 + 4552);
    t5 = (t0 + 2700);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB16;

LAB20:    xsi_set_current_line(99, ng0);
    t1 = (t0 + 4560);
    t5 = (t0 + 2700);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB16;

LAB21:    xsi_set_current_line(100, ng0);
    t1 = (t0 + 4568);
    t5 = (t0 + 2700);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB16;

LAB22:    xsi_set_current_line(101, ng0);
    t1 = (t0 + 4576);
    t5 = (t0 + 2700);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB16;

LAB23:    xsi_set_current_line(102, ng0);
    t1 = (t0 + 4584);
    t5 = (t0 + 2700);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB16;

LAB24:    xsi_set_current_line(103, ng0);
    t1 = (t0 + 4592);
    t5 = (t0 + 2700);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB16;

LAB25:    xsi_set_current_line(104, ng0);
    t1 = (t0 + 4600);
    t5 = (t0 + 2700);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB16;

LAB26:    xsi_set_current_line(105, ng0);
    t1 = (t0 + 4608);
    t5 = (t0 + 2700);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB16;

LAB27:    xsi_set_current_line(106, ng0);
    t1 = (t0 + 4616);
    t5 = (t0 + 2700);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB16;

LAB28:    xsi_set_current_line(107, ng0);
    t1 = (t0 + 4624);
    t5 = (t0 + 2700);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB16;

LAB29:    xsi_set_current_line(108, ng0);
    t1 = (t0 + 4632);
    t5 = (t0 + 2700);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB16;

LAB30:    xsi_set_current_line(109, ng0);
    t1 = (t0 + 4640);
    t5 = (t0 + 2700);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB16;

LAB31:    xsi_set_current_line(110, ng0);
    t1 = (t0 + 4648);
    t5 = (t0 + 2700);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB16;

LAB32:    xsi_set_current_line(111, ng0);
    t1 = (t0 + 4656);
    t5 = (t0 + 2700);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_delta(t5, 0U, 8U, 0LL);
    goto LAB16;

LAB50:;
}


extern void work_a_1774854872_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1774854872_3212880686_p_0};
	xsi_register_didat("work_a_1774854872_3212880686", "isim/_tmp/work/a_1774854872_3212880686.didat");
	xsi_register_executes(pe);
}
