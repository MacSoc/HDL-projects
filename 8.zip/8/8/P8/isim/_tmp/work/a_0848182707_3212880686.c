/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                         */
/*  \   \        Copyright (c) 2003-2007 Xilinx, Inc.                 */
/*  /   /        All Right Reserved.                                  */
/* /---/   /\                                                         */
/* \   \  /  \                                                        */
/*  \___\/\___\                                                       */
/**********************************************************************/

/* This file is designed for use with ISim build 0x734844ce */

#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/studia/Sem4/IUP/8/P8/PS2.vhd";
extern char *IEEE_P_2592010699;

unsigned char p_2592010699_sub_1258338084_2592010699(char *, char *, unsigned int , unsigned int );
unsigned char p_2592010699_sub_1744673427_2592010699(char *, char *, unsigned int , unsigned int );
unsigned char p_2592010699_sub_2507238156_2592010699(char *, unsigned char , unsigned char );


static void work_a_0848182707_3212880686_p_0(char *t0)
{
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned char t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    int t15;
    int t16;
    int t18;
    char *t19;
    int t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;

LAB0:    xsi_set_current_line(32, ng0);
    t1 = (t0 + 528U);
    t2 = p_2592010699_sub_1744673427_2592010699(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 2552);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(33, ng0);
    t3 = (t0 + 1076U);
    t4 = *((char **)t3);
    t5 = (3 - 4);
    t6 = (t5 * -1);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t3 = (t4 + t8);
    t9 = *((unsigned char *)t3);
    t10 = (t0 + 2612);
    t11 = (t10 + 32U);
    t12 = *((char **)t11);
    t13 = (t12 + 40U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = t9;
    xsi_driver_first_trans_delta(t10, 0U, 1, 0LL);
    xsi_set_current_line(34, ng0);
    t1 = (t0 + 1076U);
    t3 = *((char **)t1);
    t5 = (2 - 4);
    t6 = (t5 * -1);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t1 = (t3 + t8);
    t2 = *((unsigned char *)t1);
    t4 = (t0 + 2612);
    t10 = (t4 + 32U);
    t11 = *((char **)t10);
    t12 = (t11 + 40U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = t2;
    xsi_driver_first_trans_delta(t4, 1U, 1, 0LL);
    xsi_set_current_line(35, ng0);
    t1 = (t0 + 1076U);
    t3 = *((char **)t1);
    t5 = (0 - 4);
    t6 = (t5 * -1);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t1 = (t3 + t8);
    t2 = *((unsigned char *)t1);
    t4 = (t0 + 2612);
    t10 = (t4 + 32U);
    t11 = *((char **)t10);
    t12 = (t11 + 40U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = t2;
    xsi_driver_first_trans_delta(t4, 3U, 1, 0LL);
    xsi_set_current_line(36, ng0);
    t1 = (t0 + 724U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t1 = (t0 + 2612);
    t4 = (t1 + 32U);
    t10 = *((char **)t4);
    t11 = (t10 + 40U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t2;
    xsi_driver_first_trans_delta(t1, 4U, 1, 0LL);
    xsi_set_current_line(37, ng0);
    t1 = (t0 + 1076U);
    t3 = *((char **)t1);
    t1 = (t0 + 4209);
    t5 = xsi_mem_cmp(t1, t3, 5U);
    if (t5 == 1)
        goto LAB6;

LAB12:    t10 = (t0 + 4214);
    t15 = xsi_mem_cmp(t10, t3, 5U);
    if (t15 == 1)
        goto LAB7;

LAB13:    t12 = (t0 + 4219);
    t16 = xsi_mem_cmp(t12, t3, 5U);
    if (t16 == 1)
        goto LAB8;

LAB14:    t14 = (t0 + 4224);
    t18 = xsi_mem_cmp(t14, t3, 5U);
    if (t18 == 1)
        goto LAB9;

LAB15:    t19 = (t0 + 4229);
    t21 = xsi_mem_cmp(t19, t3, 5U);
    if (t21 == 1)
        goto LAB10;

LAB16:
LAB11:    xsi_set_current_line(43, ng0);
    t1 = (t0 + 2648);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t10 = (t4 + 40U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB5:    goto LAB3;

LAB6:    xsi_set_current_line(38, ng0);
    t22 = (t0 + 2648);
    t23 = (t22 + 32U);
    t24 = *((char **)t23);
    t25 = (t24 + 40U);
    t26 = *((char **)t25);
    *((unsigned char *)t26) = (unsigned char)3;
    xsi_driver_first_trans_fast(t22);
    goto LAB5;

LAB7:    xsi_set_current_line(39, ng0);
    t1 = (t0 + 2648);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t10 = (t4 + 40U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB5;

LAB8:    xsi_set_current_line(40, ng0);
    t1 = (t0 + 2648);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t10 = (t4 + 40U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB5;

LAB9:    xsi_set_current_line(41, ng0);
    t1 = (t0 + 2648);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t10 = (t4 + 40U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB5;

LAB10:    xsi_set_current_line(42, ng0);
    t1 = (t0 + 2648);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t10 = (t4 + 40U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB5;

LAB17:;
}

static void work_a_0848182707_3212880686_p_1(char *t0)
{
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    int t5;
    unsigned char t6;
    char *t7;
    unsigned char t8;
    unsigned char t9;
    char *t10;
    int t11;
    int t12;
    int t13;
    int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned char t28;
    unsigned char t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned char t33;
    unsigned char t34;
    char *t35;
    char *t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned char t40;
    unsigned char t41;
    char *t42;
    char *t43;
    int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned char t48;
    unsigned char t49;
    char *t50;
    char *t51;
    int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned char t56;
    unsigned char t57;
    char *t58;
    char *t59;
    int t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    unsigned char t64;
    unsigned char t65;
    unsigned char t66;
    char *t67;
    char *t68;

LAB0:    xsi_set_current_line(61, ng0);
    t1 = (t0 + 968U);
    t2 = p_2592010699_sub_1258338084_2592010699(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 2560);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(63, ng0);
    t3 = (t0 + 1480U);
    t4 = *((char **)t3);
    t5 = *((int *)t4);
    t6 = (t5 == 0);
    if (t6 != 0)
        goto LAB5;

LAB7:    t1 = (t0 + 1480U);
    t3 = *((char **)t1);
    t5 = *((int *)t3);
    t6 = (t5 >= 1);
    if (t6 == 1)
        goto LAB13;

LAB14:    t2 = (unsigned char)0;

LAB15:    if (t2 != 0)
        goto LAB11;

LAB12:    t1 = (t0 + 1480U);
    t3 = *((char **)t1);
    t5 = *((int *)t3);
    t2 = (t5 == 9);
    if (t2 != 0)
        goto LAB16;

LAB17:    t1 = (t0 + 1480U);
    t3 = *((char **)t1);
    t5 = *((int *)t3);
    t2 = (t5 == 10);
    if (t2 != 0)
        goto LAB21;

LAB22:
LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(65, ng0);
    t3 = (t0 + 636U);
    t7 = *((char **)t3);
    t8 = *((unsigned char *)t7);
    t9 = (t8 == (unsigned char)2);
    if (t9 != 0)
        goto LAB8;

LAB10:
LAB9:    goto LAB6;

LAB8:    xsi_set_current_line(66, ng0);
    t3 = (t0 + 1480U);
    t10 = *((char **)t3);
    t3 = (t10 + 0);
    *((int *)t3) = 1;
    goto LAB9;

LAB11:    xsi_set_current_line(71, ng0);
    t1 = (t0 + 636U);
    t7 = *((char **)t1);
    t9 = *((unsigned char *)t7);
    t1 = (t0 + 1480U);
    t10 = *((char **)t1);
    t12 = *((int *)t10);
    t13 = (t12 - 1);
    t14 = (t13 - 7);
    t15 = (t14 * -1);
    t16 = (1 * t15);
    t17 = (0U + t16);
    t1 = (t0 + 2684);
    t18 = (t1 + 32U);
    t19 = *((char **)t18);
    t20 = (t19 + 40U);
    t21 = *((char **)t20);
    *((unsigned char *)t21) = t9;
    xsi_driver_first_trans_delta(t1, t17, 1, 0LL);
    xsi_set_current_line(72, ng0);
    t1 = (t0 + 1480U);
    t3 = *((char **)t1);
    t5 = *((int *)t3);
    t11 = (t5 + 1);
    t1 = (t0 + 1480U);
    t4 = *((char **)t1);
    t1 = (t4 + 0);
    *((int *)t1) = t11;
    goto LAB6;

LAB13:    t1 = (t0 + 1480U);
    t4 = *((char **)t1);
    t11 = *((int *)t4);
    t8 = (t11 <= 8);
    t2 = t8;
    goto LAB15;

LAB16:    xsi_set_current_line(76, ng0);
    t1 = (t0 + 636U);
    t4 = *((char **)t1);
    t6 = *((unsigned char *)t4);
    t1 = (t0 + 2720);
    t7 = (t1 + 32U);
    t10 = *((char **)t7);
    t18 = (t10 + 40U);
    t19 = *((char **)t18);
    *((unsigned char *)t19) = t6;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(78, ng0);
    t1 = (t0 + 1164U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t1 = (t0 + 1252U);
    t4 = *((char **)t1);
    t5 = (0 - 7);
    t15 = (t5 * -1);
    t16 = (1U * t15);
    t17 = (0 + t16);
    t1 = (t4 + t17);
    t6 = *((unsigned char *)t1);
    t7 = (t0 + 1252U);
    t10 = *((char **)t7);
    t11 = (1 - 7);
    t22 = (t11 * -1);
    t23 = (1U * t22);
    t24 = (0 + t23);
    t7 = (t10 + t24);
    t8 = *((unsigned char *)t7);
    t9 = p_2592010699_sub_2507238156_2592010699(IEEE_P_2592010699, t6, t8);
    t18 = (t0 + 1252U);
    t19 = *((char **)t18);
    t12 = (2 - 7);
    t25 = (t12 * -1);
    t26 = (1U * t25);
    t27 = (0 + t26);
    t18 = (t19 + t27);
    t28 = *((unsigned char *)t18);
    t29 = p_2592010699_sub_2507238156_2592010699(IEEE_P_2592010699, t9, t28);
    t20 = (t0 + 1252U);
    t21 = *((char **)t20);
    t13 = (3 - 7);
    t30 = (t13 * -1);
    t31 = (1U * t30);
    t32 = (0 + t31);
    t20 = (t21 + t32);
    t33 = *((unsigned char *)t20);
    t34 = p_2592010699_sub_2507238156_2592010699(IEEE_P_2592010699, t29, t33);
    t35 = (t0 + 1252U);
    t36 = *((char **)t35);
    t14 = (4 - 7);
    t37 = (t14 * -1);
    t38 = (1U * t37);
    t39 = (0 + t38);
    t35 = (t36 + t39);
    t40 = *((unsigned char *)t35);
    t41 = p_2592010699_sub_2507238156_2592010699(IEEE_P_2592010699, t34, t40);
    t42 = (t0 + 1252U);
    t43 = *((char **)t42);
    t44 = (5 - 7);
    t45 = (t44 * -1);
    t46 = (1U * t45);
    t47 = (0 + t46);
    t42 = (t43 + t47);
    t48 = *((unsigned char *)t42);
    t49 = p_2592010699_sub_2507238156_2592010699(IEEE_P_2592010699, t41, t48);
    t50 = (t0 + 1252U);
    t51 = *((char **)t50);
    t52 = (6 - 7);
    t53 = (t52 * -1);
    t54 = (1U * t53);
    t55 = (0 + t54);
    t50 = (t51 + t55);
    t56 = *((unsigned char *)t50);
    t57 = p_2592010699_sub_2507238156_2592010699(IEEE_P_2592010699, t49, t56);
    t58 = (t0 + 1252U);
    t59 = *((char **)t58);
    t60 = (7 - 7);
    t61 = (t60 * -1);
    t62 = (1U * t61);
    t63 = (0 + t62);
    t58 = (t59 + t63);
    t64 = *((unsigned char *)t58);
    t65 = p_2592010699_sub_2507238156_2592010699(IEEE_P_2592010699, t57, t64);
    t66 = (t2 == t65);
    if (t66 != 0)
        goto LAB18;

LAB20:    xsi_set_current_line(82, ng0);
    t1 = (t0 + 1480U);
    t3 = *((char **)t1);
    t1 = (t3 + 0);
    *((int *)t1) = 0;

LAB19:    goto LAB6;

LAB18:    xsi_set_current_line(80, ng0);
    t67 = (t0 + 1480U);
    t68 = *((char **)t67);
    t67 = (t68 + 0);
    *((int *)t67) = 10;
    goto LAB19;

LAB21:    xsi_set_current_line(88, ng0);
    t1 = (t0 + 1480U);
    t4 = *((char **)t1);
    t1 = (t4 + 0);
    *((int *)t1) = 0;
    xsi_set_current_line(89, ng0);
    t1 = (t0 + 1252U);
    t3 = *((char **)t1);
    t1 = (t0 + 2756);
    t4 = (t1 + 32U);
    t7 = *((char **)t4);
    t10 = (t7 + 40U);
    t18 = *((char **)t10);
    memcpy(t18, t3, 8U);
    xsi_driver_first_trans_fast_port(t1);
    goto LAB6;

}

static void work_a_0848182707_3212880686_p_2(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(97, ng0);

LAB3:    t1 = (t0 + 988U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 2792);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 2568);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_0848182707_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0848182707_3212880686_p_0,(void *)work_a_0848182707_3212880686_p_1,(void *)work_a_0848182707_3212880686_p_2};
	xsi_register_didat("work_a_0848182707_3212880686", "isim/_tmp/work/a_0848182707_3212880686.didat");
	xsi_register_executes(pe);
}
