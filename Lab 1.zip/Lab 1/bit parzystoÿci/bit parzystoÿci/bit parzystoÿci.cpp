﻿#include <iostream>

using namespace std;

int EXOR(int a, int b)
{
    return (a ^ b);
}

int main()
{
	// Stany wejściowe oraz stan wyjściowy
	int b1, b2, b3, b4, b5, b6, b7, b8, y;
	
	// Stany wyjsciowe bramek
	int YB1, YB2, YB3, YB4, YB5, YB6, YB7;

	// Licznik bitow o stanie 1
	int cnt1;

	// Licznik slow
	int wc = 0;

    for (b8 = 0; b8 < 2; b8++)
        for (b7 = 0; b7 < 2; b7++)
            for (b6 = 0; b6 < 2; b6++)
                for (b5 = 0; b5 < 2; b5++)
                    for (b4 = 0; b4 < 2; b4++)
                        for (b3 = 0; b3 < 2; b3++)
                            for (b2 = 0; b2 < 2; b2++)
                                for (b1 = 0; b1 < 2; b1++)
                                {
                                    // Symulacja sieci

                                    YB1 = EXOR(b1, b2);
                                    YB2 = EXOR(b3, b4);
                                    YB3 = EXOR(b5, b6);
                                    YB4 = EXOR(b7, b8);
                                    YB5 = EXOR(YB1, YB2);
                                    YB6 = EXOR(YB3, YB4);
                                    YB7 = EXOR(YB5, YB6);

                                    // Stan wyjściowy

                                    y = YB7;

                                    // Obliczamy ilość bitów 1

                                    cnt1 = 
                                        b1 + b2 + b3 + b4 +
                                        b5 + b6 + b7 + b8;

                                    // Wyświetlamy wyniki

                                    cout << b8 << b7 << b6 << b5
                                        << b4 << b3 << b2 << b1
                                        << "|" << y << " - ";
                                    if (cnt1 % 2 != y) cout << "??";
                                    else         cout << "OK";
                                    cout << "   ";
                                    wc++;
                                    if (wc == 4)
                                    {
                                        wc = 0;
                                        cout << endl;
                                    }
                                }
    cout << endl;

    return 0;


}